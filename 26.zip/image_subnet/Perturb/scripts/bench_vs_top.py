"""Benchmark the miner attack pipeline against the top-miner reference score.

Uses the local assets/dog_1.jpg + augmentations (crops/flips/color shifts) to
build a small but realistic test set, runs forward() on each, and computes the
exact validator score formula.

Top miner reference (from user's data):
    score=0.957700  norm=0.003922  rmse=0.000142  ssim=0.999996  psnr=76.96  t≈840 ms
"""
from __future__ import annotations
import asyncio
import os
import sys
import time
import types

import torch
from PIL import Image

sys.path.insert(0, "/workspace/image_subnet/Perturb")

from neurons import miner as M  # noqa: E402
from perturbnet.image_io import encode_image_b64, decode_image_b64  # noqa: E402
from perturbnet.model import (  # noqa: E402
    load_efficientnet_v2_m,
    predict_index,
    LABELS as IMAGENET_LABELS,
)
from perturbnet.protocol import AttackChallenge  # noqa: E402

# Validator constants (perturbnet/constants.py defaults)
PERTURBATION_WEIGHT = 0.65
SPEED_WEIGHT = 0.35
LINF_W = 0.7
RMSE_W = 0.3
MIN_LINF = 0.003
MAX_LINF = 0.03
TIMEOUT_S = 30


def _say(msg: str) -> None:
    print(f"[bench] {msg}", flush=True)


def _load_dog(device: str) -> torch.Tensor:
    img = Image.open("/workspace/image_subnet/Perturb/assets/dog_1.jpg").convert("RGB")
    img = img.resize((224, 224), Image.BILINEAR)
    arr = torch.tensor(list(img.tobytes()), dtype=torch.uint8).view(224, 224, 3)
    chw = arr.permute(2, 0, 1).float() / 255.0  # already on the 1/255 grid
    return chw.to(device)


def _augment(base: torch.Tensor, idx: int) -> torch.Tensor:
    """Deterministic augmentation; each idx produces a distinct image."""
    g = torch.Generator(device=base.device).manual_seed(1000 + idx)
    out = base.clone()
    # horizontal flip
    if idx % 2 == 1:
        out = out.flip(-1)
    # vertical flip on every 4th
    if idx % 4 == 3:
        out = out.flip(-2)
    # small random color shift in the 0..255 grid space, then snap back
    shift = (torch.randint(-8, 9, (3, 1, 1), generator=g, device=base.device) / 255.0)
    out = (out + shift).clamp(0.0, 1.0)
    # quantize to grid (real PNG inputs are on-grid)
    out = (out * 255.0).round() / 255.0
    return out


def _validator_score(clean: torch.Tensor, adv: torch.Tensor, eps: float, t_ms: float) -> dict:
    """Mirror neurons/validator.verify_and_score's success-path math."""
    if adv.shape != clean.shape:
        return {"reason": "shape_mismatch", "score": 0.0}
    if adv.min().item() < 0 or adv.max().item() > 1:
        return {"reason": "value_out_of_range", "score": 0.0}
    norm = float((adv - clean).abs().max().item())
    if norm < MIN_LINF:
        return {"reason": "below_min_delta", "score": 0.0, "norm": norm}
    eff_max = min(eps, MAX_LINF)
    if norm > eff_max:
        return {"reason": "above_max_delta", "score": 0.0, "norm": norm}
    rmse = float(torch.sqrt(torch.mean((adv - clean) ** 2)).item())
    ssim = M._compute_ssim(clean, adv)
    if ssim < 0.98:
        return {"reason": "below_min_ssim", "score": 0.0, "norm": norm, "rmse": rmse, "ssim": ssim}
    psnr = M._compute_psnr_db(clean, adv)
    # validator default min_psnr_db is 0 (no PSNR gate enabled by default)
    denom = max(1e-12, eff_max - MIN_LINF)
    linf_ratio = max(0.0, min(1.0, (norm - MIN_LINF) / denom))
    rmse_ratio = max(0.0, min(1.0, rmse / max(1e-12, eff_max)))
    linf_score = (1.0 - linf_ratio) ** 2
    rmse_score = (1.0 - rmse_ratio) ** 2
    quality = (LINF_W * linf_score + RMSE_W * rmse_score) / (LINF_W + RMSE_W)
    speed = 1.0 - min(t_ms / (TIMEOUT_S * 1000.0), 1.0)
    score = PERTURBATION_WEIGHT * quality + SPEED_WEIGHT * speed
    return {
        "reason": "success",
        "score": float(score),
        "norm": norm,
        "rmse": rmse,
        "ssim": ssim,
        "psnr_db": psnr,
        "linf_score": linf_score,
        "rmse_score": rmse_score,
        "quality": quality,
        "speed_score": speed,
    }


def main() -> int:
    device = "cuda" if torch.cuda.is_available() else "cpu"
    _say(f"device={device}")
    try:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass
    model = load_efficientnet_v2_m(device=device)
    model.eval()

    # Build stub miner
    stub = types.SimpleNamespace()
    stub.model = model
    stub.device = device
    stub._log_step_start = lambda *a, **kw: None
    for name in (
        "_verify_candidate",
        "_sparse_jsma_attack",
        "_deepfool_linf_multi",
        "_saliency_mask",
        "_mi_pgd_targeted",
        "forward",
    ):
        setattr(stub, name, types.MethodType(getattr(M.PerturbMiner, name), stub))

    # Pre-warm
    with torch.no_grad():
        from perturbnet.model import logits_for_images
        _ = logits_for_images(model=model, image_bchw=torch.zeros(1, 3, 224, 224, device=device))
        if device == "cuda":
            torch.cuda.synchronize()

    base = _load_dog(device)
    n_images = 8
    images = [base] + [_augment(base, i) for i in range(1, n_images)]
    eps = 0.10  # typical validator epsilon

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)

    rows = []
    for i, clean in enumerate(images):
        true_idx = predict_index(model=model, image_chw=clean)
        true_label = IMAGENET_LABELS[true_idx]
        syn = AttackChallenge(
            task_id=f"bench-{i}",
            prompt="bench",
            clean_image_b64=encode_image_b64(clean.cpu()),
            true_label=true_label,
            norm_type="Linf",
            epsilon=eps,
            min_delta=0.003,
        )
        t0 = time.perf_counter()
        out = loop.run_until_complete(stub.forward(syn))
        dt_ms = (time.perf_counter() - t0) * 1000.0

        if out.perturbed_image_b64 == out.clean_image_b64:
            score = {"reason": "returned_clean", "score": 0.0}
        else:
            adv = decode_image_b64(out.perturbed_image_b64).to(device)
            score = _validator_score(clean=clean, adv=adv, eps=eps, t_ms=dt_ms)
        rows.append((i, true_label, dt_ms, score))

    # ---- Print per-image results ----
    print()
    print(f"{'#':>2} {'true_label':<25} {'reason':<20} {'norm':>8} {'rmse':>10} "
          f"{'ssim':>9} {'psnr':>7} {'t_ms':>7} {'score':>8}")
    print("-" * 110)
    for i, lbl, dt_ms, s in rows:
        print(
            f"{i:>2} {lbl[:25]:<25} {s.get('reason','?'):<20} "
            f"{s.get('norm',0.0):>8.5f} {s.get('rmse',0.0):>10.6f} "
            f"{s.get('ssim',0.0):>9.5f} {s.get('psnr_db',0.0):>7.2f} "
            f"{dt_ms:>7.0f} {s.get('score',0.0):>8.4f}"
        )

    # ---- Aggregate ----
    successes = [r[3] for r in rows if r[3].get("reason") == "success"]
    n_ok = len(successes)
    n_total = len(rows)
    mean_score = sum(s["score"] for s in successes) / max(1, n_ok)
    overall_mean = sum(r[3].get("score", 0.0) for r in rows) / n_total
    print("-" * 110)
    print(f"successes:    {n_ok}/{n_total}")
    print(f"mean(success): {mean_score:.4f}")
    print(f"mean(overall): {overall_mean:.4f}")
    if successes:
        print(
            f"avg norm={sum(s['norm'] for s in successes)/n_ok:.5f} "
            f"avg rmse={sum(s['rmse'] for s in successes)/n_ok:.6f} "
            f"avg ssim={sum(s['ssim'] for s in successes)/n_ok:.5f} "
            f"avg psnr={sum(s['psnr_db'] for s in successes)/n_ok:.2f} "
            f"avg t_ms={sum(r[2] for r,s in zip(rows,[r[3] for r in rows]) if s.get('reason')=='success')/n_ok:.0f}"
        )

    print()
    print("REFERENCE — top miner (from user data):")
    print(f"  score=0.9577  norm=0.003922  rmse=0.000142  ssim=0.999996  psnr=76.96  t≈840 ms")
    print()
    if overall_mean > 0.9577:
        print(f"VERDICT: WIN by {overall_mean - 0.9577:+.4f}")
    elif overall_mean > 0.95:
        print(f"VERDICT: COMPETITIVE, gap = {overall_mean - 0.9577:+.4f}")
    else:
        print(f"VERDICT: BEHIND, gap = {overall_mean - 0.9577:+.4f}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
