"""Smoke test for the rewritten miner attack pipeline.

Bypasses wallet/subtensor instantiation by binding PerturbMiner methods to a
lightweight stub with .model / .device. Exercises:
  - _quantize_snap, _compute_ssim, _compute_psnr_db
  - _verify_candidate
  - _deepfool_linf_multi
  - _saliency_mask
  - _mi_pgd_targeted
  - full forward() via a fake AttackChallenge synapse
"""
from __future__ import annotations
import asyncio
import base64
import io
import logging
import sys
import time
import types

import torch

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
log = logging.getLogger("smoke")


def _say(msg: str) -> None:
    print(f"[smoke] {msg}", flush=True)

sys.path.insert(0, "/workspace/image_subnet/Perturb")

from neurons import miner as M  # noqa: E402
from perturbnet.image_io import encode_image_b64, decode_image_b64  # noqa: E402
from perturbnet.model import load_efficientnet_v2_m, predict_index, LABELS as IMAGENET_LABELS  # noqa: E402
from perturbnet.protocol import AttackChallenge  # noqa: E402


def main() -> int:
    device = "cuda" if torch.cuda.is_available() else "cpu"
    _say(f"device={device}")

    _say("loading EfficientNetV2-M...")
    model = load_efficientnet_v2_m(device=device)
    model.eval()

    # Build a structured 224x224 image so the network produces a real prediction.
    torch.manual_seed(0)
    H = W = 224
    base = torch.zeros(3, H, W)
    for c in range(3):
        x = torch.linspace(0, 1, W).unsqueeze(0).expand(H, W)
        y = torch.linspace(0, 1, H).unsqueeze(1).expand(H, W)
        base[c] = (0.5 + 0.4 * torch.sin(6.0 * (x + 0.3 * c)) * torch.cos(4.0 * y)).clamp(0, 1)
    # Snap to the uint8 grid up-front: real PNG inputs are always on-grid, and
    # the sparse stage relies on this (otherwise quantization shifts dominate
    # the perturbation norm).
    clean = (base.clamp(0.0, 1.0) * 255.0).round() / 255.0
    clean = clean.to(device)

    true_idx = predict_index(model=model, image_chw=clean)
    _say(f"true_idx={true_idx} ({IMAGENET_LABELS[true_idx] if true_idx < len(IMAGENET_LABELS) else '?'})")

    # ---- 1. Pure helpers -------------------------------------------------
    q = M._quantize_snap(clean)
    assert q.shape == clean.shape
    ssim_self = M._compute_ssim(clean, clean)
    psnr_self = M._compute_psnr_db(clean, clean)
    _say(f"helpers ok: ssim_self={ssim_self:.4f} psnr_self={psnr_self:.2f}")
    assert ssim_self > 0.999
    assert psnr_self > 90

    # ---- 2. Build stub & bind methods -----------------------------------
    stub = types.SimpleNamespace()
    stub.model = model
    stub.device = device

    def _bind(name):
        fn = getattr(M.PerturbMiner, name)
        setattr(stub, name, types.MethodType(fn, stub))

    for name in ("_verify_candidate", "_sparse_jsma_attack", "_deepfool_linf_multi", "_saliency_mask", "_mi_pgd_targeted"):
        _bind(name)

    d_eff = max(M.SAFE_MIN_LINF + M.QUANT_STEP, 0.03 - M.QUANT_STEP)
    min_n = M.SAFE_MIN_LINF
    min_n_sparse = M.VALIDATOR_MIN_LINF + 0.0005
    _say(f"d_eff={d_eff:.5f} min_n={min_n:.5f} min_n_sparse={min_n_sparse:.5f}")

    # ---- 2.5. Sparse JSMA -----------------------------------------------
    t0 = time.perf_counter()
    sp = stub._sparse_jsma_attack(clean=clean, true_idx=true_idx, d_eff=d_eff, min_n=min_n_sparse)
    sp_dt = 1000 * (time.perf_counter() - t0)
    if sp is None:
        _say(f"sparse_jsma t={sp_dt:.1f}ms result=None")
    else:
        cand_sp, t_sp, k_sp = sp
        ok, reason, info = stub._verify_candidate(clean, cand_sp, true_idx, d_eff, min_n_sparse)
        _say(f"sparse_jsma t={sp_dt:.1f}ms target={t_sp} k={k_sp} ok={ok} reason={reason} info={info}")

    # ---- 3. DeepFool -----------------------------------------------------
    t0 = time.perf_counter()
    df = stub._deepfool_linf_multi(clean=clean, true_idx=true_idx, top_k=5)
    _say(f"deepfool t={1000*(time.perf_counter()-t0):.1f}ms result={'None' if df is None else f'target={df[1]} norm={df[2]:.5f}'}")
    assert df is not None, "DeepFool returned None"
    delta_df, target_idx, raw_norm = df

    # Verify the scaled delta
    if raw_norm > 1e-9:
        target_n = min(d_eff, max(min_n * 1.2, raw_norm * 1.1))
        delta_df_scaled = delta_df * (target_n / raw_norm)
    else:
        delta_df_scaled = delta_df
    cand_df = M._quantize_snap(clean + delta_df_scaled)
    ok, reason, info = stub._verify_candidate(clean, cand_df, true_idx, d_eff, min_n)
    _say(f"deepfool verify: ok={ok} reason={reason} info={info}")

    # ---- 4. Saliency mask -----------------------------------------------
    mask = stub._saliency_mask(clean=clean, true_idx=true_idx, top_pct=8.0)
    _say(f"saliency mask shape={tuple(mask.shape)} active_frac={mask.mean().item():.3f}")
    assert mask.shape == (1, H, W)

    # ---- 5. MI-PGD -------------------------------------------------------
    t0 = time.perf_counter()
    cand_pgd = stub._mi_pgd_targeted(
        clean=clean,
        true_idx=true_idx,
        target_idx=target_idx,
        init_delta=delta_df.detach(),
        mask=mask,
        radius=0.022,
        d_eff=d_eff,
        min_n=min_n,
        steps=8,
    )
    _say(f"mi_pgd t={1000*(time.perf_counter()-t0):.1f}ms result={'None' if cand_pgd is None else 'tensor'}")
    if cand_pgd is not None:
        ok, reason, info = stub._verify_candidate(clean, cand_pgd, true_idx, d_eff, min_n)
        _say(f"mi_pgd verify: ok={ok} reason={reason} info={info}")

    # ---- 6. End-to-end forward() via stub -------------------------------
    # Add the remaining attributes/methods forward() needs.
    stub._log_step_start = lambda *a, **kw: None
    stub.forward = types.MethodType(M.PerturbMiner.forward, stub)

    syn = AttackChallenge(
        task_id="smoke-1",
        prompt="smoke",
        clean_image_b64=encode_image_b64(clean.cpu()),
        true_label=IMAGENET_LABELS[true_idx] if true_idx < len(IMAGENET_LABELS) else str(true_idx),
        norm_type="Linf",
        epsilon=0.10,
        min_delta=0.003,
    )

    t0 = time.perf_counter()
    out = asyncio.get_event_loop().run_until_complete(stub.forward(syn))
    dt = 1000 * (time.perf_counter() - t0)
    _say(f"forward end-to-end t={dt:.1f}ms")

    assert out.perturbed_image_b64 is not None
    if out.perturbed_image_b64 == out.clean_image_b64:
        _say("ERROR " + "forward returned clean image (attack failed)")
        return 1

    # Decode and verify against validator-equivalent gates. The min_n threshold
    # depends on which stage actually fired; sparse uses 0.0035, dense uses min_n.
    final = decode_image_b64(out.perturbed_image_b64).to(device)
    # Try the looser threshold first (sparse-stage success path); fall back to dense.
    ok, reason, info = stub._verify_candidate(clean, final, true_idx, d_eff, min_n_sparse)
    if not ok:
        ok, reason, info = stub._verify_candidate(clean, final, true_idx, d_eff, min_n)
    _say(f"FINAL verify: ok={ok} reason={reason} info={info}")
    if not ok:
        return 2

    _say("SMOKE TEST PASSED")
    return 0


if __name__ == "__main__":
    sys.exit(main())
