"""Run the miner attack on assets/dog_1.jpg and save a side-by-side visualization.

Outputs (PNG) into Perturb/assets/attack_demo/:
    clean.png        — input image (224x224, on uint8 grid)
    adversarial.png  — miner's perturbed output
    diff.png         — |adv - clean| amplified for visibility
    side_by_side.png — three panels stitched horizontally with labels

Run:
    LD_PRELOAD=/venv/main/lib/libstdc++.so.6 python3 scripts/visualize_attack.py
"""
from __future__ import annotations
import asyncio
import os
import sys
import time
import types

import numpy as np
import torch
from PIL import Image, ImageDraw, ImageFont

sys.path.insert(0, "/workspace/image_subnet/Perturb")

from neurons import miner as M  # noqa: E402
from perturbnet.image_io import encode_image_b64, decode_image_b64  # noqa: E402
from perturbnet.model import (  # noqa: E402
    load_efficientnet_v2_m,
    logits_for_images,
    predict_index,
    LABELS as IMAGENET_LABELS,
)
from perturbnet.protocol import AttackChallenge  # noqa: E402

ASSET = "/workspace/image_subnet/Perturb/assets/dog_1.jpg"
OUT_DIR = "/workspace/image_subnet/Perturb/assets/attack_demo"


def _to_uint8_hwc(chw: torch.Tensor) -> np.ndarray:
    return (chw.detach().cpu().clamp(0, 1).permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)


def _load_clean(device: str) -> torch.Tensor:
    img = Image.open(ASSET).convert("RGB").resize((224, 224), Image.BILINEAR)
    arr = np.asarray(img, dtype=np.float32) / 255.0
    return torch.from_numpy(arr).permute(2, 0, 1).contiguous().to(device)


def _build_stub(model, device):
    stub = types.SimpleNamespace()
    stub.model = model
    stub.device = device
    stub._log_step_start = lambda *a, **kw: None
    for name in (
        "_verify_candidate",
        "_sparse_jsma_attack",
        "_deepfool_linf_multi",
        "_saliency_mask",
        "_mi_pgd_targeted",
        "forward",
    ):
        setattr(stub, name, types.MethodType(getattr(M.PerturbMiner, name), stub))
    return stub


def _annotate(img: Image.Image, lines: list[str]) -> Image.Image:
    out = img.copy()
    draw = ImageDraw.Draw(out)
    try:
        font = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", 13)
    except Exception:
        font = ImageFont.load_default()
    pad = 4
    y = pad
    for ln in lines:
        bbox = draw.textbbox((pad, y), ln, font=font)
        draw.rectangle(bbox, fill=(0, 0, 0))
        draw.text((pad, y), ln, fill=(255, 255, 255), font=font)
        y = bbox[3] + 1
    return out


def main() -> int:
    os.makedirs(OUT_DIR, exist_ok=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"[viz] device={device}", flush=True)

    try:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    except Exception:
        pass

    model = load_efficientnet_v2_m(device=device)
    model.eval()
    stub = _build_stub(model, device)

    # Pre-warm
    with torch.no_grad():
        _ = logits_for_images(model=model, image_bchw=torch.zeros(1, 3, 224, 224, device=device))
        if device == "cuda":
            torch.cuda.synchronize()

    clean = _load_clean(device)
    true_idx = predict_index(model=model, image_chw=clean)
    true_label = IMAGENET_LABELS[true_idx]
    with torch.no_grad():
        clean_logits = logits_for_images(model=model, image_bchw=clean.unsqueeze(0))[0]
        clean_probs = torch.softmax(clean_logits, dim=0)
        clean_conf = float(clean_probs[true_idx].item())
    print(f"[viz] clean prediction: idx={true_idx} label={true_label!r} conf={clean_conf:.4f}")

    # Attack
    syn = AttackChallenge(
        task_id="viz",
        prompt="viz",
        clean_image_b64=encode_image_b64(clean.cpu()),
        true_label=true_label,
        norm_type="Linf",
        epsilon=0.10,
        min_delta=0.003,
    )
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    t0 = time.perf_counter()
    out = loop.run_until_complete(stub.forward(syn))
    dt_ms = (time.perf_counter() - t0) * 1000.0

    if out.perturbed_image_b64 == out.clean_image_b64:
        print("[viz] miner returned clean (attack failed)")
        return 1

    adv = decode_image_b64(out.perturbed_image_b64).to(device)
    norm = float((adv - clean).abs().max().item())
    rmse = float(torch.sqrt(torch.mean((adv - clean) ** 2)).item())
    ssim = M._compute_ssim(clean, adv)
    psnr = M._compute_psnr_db(clean, adv)
    with torch.no_grad():
        adv_logits = logits_for_images(model=model, image_bchw=adv.unsqueeze(0))[0]
        adv_probs = torch.softmax(adv_logits, dim=0)
        adv_idx = int(adv_logits.argmax().item())
        adv_label = IMAGENET_LABELS[adv_idx]
        adv_conf = float(adv_probs[adv_idx].item())
        adv_true_conf = float(adv_probs[true_idx].item())

    print(
        f"[viz] adversarial prediction: idx={adv_idx} label={adv_label!r} "
        f"conf={adv_conf:.4f} (true_label conf now={adv_true_conf:.4f})"
    )
    print(
        f"[viz] norm={norm:.5f} rmse={rmse:.6f} ssim={ssim:.6f} "
        f"psnr={psnr:.2f} t={dt_ms:.0f} ms"
    )

    # ---- Save individual PNGs ----
    Image.fromarray(_to_uint8_hwc(clean)).save(os.path.join(OUT_DIR, "clean.png"))
    Image.fromarray(_to_uint8_hwc(adv)).save(os.path.join(OUT_DIR, "adversarial.png"))

    diff = (adv - clean).abs().cpu()  # (3,H,W) in [0,1]
    diff_max = float(diff.max().item()) or 1.0
    diff_amp = (diff / diff_max).clamp(0, 1)
    diff_img = (diff_amp.permute(1, 2, 0).numpy() * 255.0).round().astype(np.uint8)
    Image.fromarray(diff_img).save(os.path.join(OUT_DIR, "diff.png"))

    # Where any channel changed at all (binary mask)
    changed_mask = (diff.sum(0) > 0).numpy().astype(np.uint8) * 255
    n_changed = int((changed_mask > 0).sum())
    Image.fromarray(changed_mask, mode="L").save(os.path.join(OUT_DIR, "changed_pixels.png"))
    print(f"[viz] modified pixels: {n_changed}/{224*224} ({100*n_changed/(224*224):.2f}%)")

    # ---- Side-by-side panel ----
    panels = [
        _annotate(
            Image.fromarray(_to_uint8_hwc(clean)),
            [f"CLEAN", f"{true_label[:22]}", f"conf={clean_conf:.3f}"],
        ),
        _annotate(
            Image.fromarray(_to_uint8_hwc(adv)),
            [
                f"ADVERSARIAL",
                f"{adv_label[:22]}",
                f"conf={adv_conf:.3f}",
                f"L_inf={norm:.4f}",
                f"RMSE={rmse:.5f}",
                f"SSIM={ssim:.4f}",
                f"t={dt_ms:.0f}ms",
            ],
        ),
        _annotate(
            Image.fromarray(diff_img),
            [f"|adv-clean| x{1.0/diff_max:.0f}", f"changed: {n_changed}px"],
        ),
    ]
    W, H = 224, 224
    canvas = Image.new("RGB", (W * 3 + 8, H), (32, 32, 32))
    for i, p in enumerate(panels):
        canvas.paste(p, (i * (W + 4), 0))
    sbs_path = os.path.join(OUT_DIR, "side_by_side.png")
    canvas.save(sbs_path)
    print(f"[viz] wrote {sbs_path}")
    print(f"[viz] artifacts in {OUT_DIR}/")
    return 0


if __name__ == "__main__":
    sys.exit(main())
